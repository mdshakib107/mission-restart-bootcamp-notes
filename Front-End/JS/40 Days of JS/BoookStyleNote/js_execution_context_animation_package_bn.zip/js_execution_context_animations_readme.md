# JavaScript Execution Context & Call Stack Animations - Bengali

এই package-এ JavaScript Execution Context, Call Stack, Stack/Heap Memory এবং Garbage Collection বোঝার জন্য একটি interactive HTML animation lesson আছে।

## কীভাবে ব্যবহার করবেন

1. `js_execution_context_animations_bn.html` ফাইলটি browser-এ open করুন।
2. বাম পাশ থেকে scene select করুন।
3. `Next`, `Previous`, বা `Autoplay` ব্যবহার করে animation দেখুন।
4. Keyboard shortcut:
   - Right Arrow: Next
   - Left Arrow: Previous
   - Space: Autoplay/Pause

## Scenes

1. Lexical Environment
2. Global Execution Context - Creation Phase
3. Execution Phase
4. Function Execution Context
5. Nested Function Flow: GEC -> FEC(testMe) -> FEC(testAgain)
6. Stack vs Heap Memory
7. Garbage Collection
8. Complete Call Stack Lifecycle

## Notes

- এই animation offline চলে। Internet বা external library দরকার নেই।
- Programming terms English রাখা হয়েছে, explanation বাংলা।
- এটি beginner revision এবং teaching/demo-এর জন্য বানানো।
