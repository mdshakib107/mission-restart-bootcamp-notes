# JavaScript Execution Context Animations — Bengali

এই package-টি JavaScript Execution Context, Call Stack, Stack/Heap memory এবং Garbage Collection বোঝার জন্য তৈরি করা interactive animation lesson।

## কীভাবে চালাবেন

1. `js_execution_context_animations_bn.html` ফাইলটি download করুন।
2. Mobile, tablet বা desktop browser-এ open করুন।
3. Scene select করুন।
4. `Previous`, `Autoplay`, `Next` button দিয়ে step-by-step animation দেখুন।

## Mobile responsive update

এই version-এ mobile-friendly layout যোগ করা হয়েছে:

- Small screen-এ sidebar automatically top navigation হয়ে যায়।
- Scene navigation horizontal swipe/scroll করা যায়।
- Code panel ও animation panel single-column layout নেয়।
- Controls mobile screen-এর bottom-এ sticky থাকে।
- Buttons touch-friendly করা হয়েছে।
- Stack/Heap, timeline, table ও code block overflow-safe করা হয়েছে।
- Very small phone এবং landscape mode-এর জন্য আলাদা responsive rules আছে।
- Reduced-motion accessibility support যোগ করা হয়েছে।

## Included scenes

1. Lexical Environment
2. Global Execution Context — Creation Phase
3. Execution Phase
4. Function Execution Context
5. Nested Function Flow
6. Stack vs Heap Memory
7. Garbage Collection
8. Complete Call Stack Lifecycle

## Files

- `js_execution_context_animations_bn.html` — main interactive animation file
- `js_execution_context_animations_readme.md` — usage notes
